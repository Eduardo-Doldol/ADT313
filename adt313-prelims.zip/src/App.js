import React from 'react';
import './App.css';
import Login from './components/user/loginFrom/login'; 
import Student from './components/user/studentInformation/student'; 
import Operation from './components/user/mathOperation/operation';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Student /> 
        <Login /> 
        <Operation /> 
      </header>
    </div>
  );
}

export default App;

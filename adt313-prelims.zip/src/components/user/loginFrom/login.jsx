import React, { useState, useEffect, useRef, useCallback, useContext, createContext } from 'react';
import './login.css';

const UserContext = createContext();

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);
  const [error, setError] = useState({ username: '', password: '' });

  const usernameRef = useRef(null);
  const passwordRef = useRef(null);

  const credentials = useRef({
    username: 'user',
    password: 'password123@',
    profile: {
      firstName: 'Eduardo',
      middleName: 'Soriano',
      lastName: 'Doldol',
      section: 'BSIT-3B',
    },
  });

  useEffect(() => {
    const timer = setTimeout(() => {
      if (username && error.username) {
        setError(prev => ({ ...prev, username: '' }));
      }
      if (password && error.password) {
        setError(prev => ({ ...prev, password: '' }));
      }
    }, 2000); 

    return () => clearTimeout(timer); 
  }, [username, password, error]);

  const togglePasswordVisibility = useCallback(() => {
    const passwordField = passwordRef.current;
    if (passwordField) {
      passwordField.type = passwordField.type === 'password' ? 'text' : 'password';
    }
  }, []);

  const [userProfile, setUserProfile] = useContext(UserContext);

  const handleLogin = useCallback(() => {
    let valid = true;

    if (!username) {
      setError(prev => ({ ...prev, username: 'This field is required.' }));
      usernameRef.current.focus(); 
      valid = false;
    }
    if (!password) {
      setError(prev => ({ ...prev, password: 'This field is required.' }));
      passwordRef.current.focus();
      valid = false;
    }

    if (!valid) return; 

    if (username === credentials.current.username && password === credentials.current.password) {
      setLoading(true);
      setTimeout(() => {
        setUserProfile(credentials.current.profile);
        setLoggedIn(true);
        setLoading(false);
      }, 3000);
    } else {
      alert('Incorrect username or password!');
    }
  }, [username, password, setUserProfile]);

  const handleLogout = useCallback(() => {
    const confirmLogout = window.confirm('Are you sure you want to log out?');
    if (confirmLogout) {
      setLoggedIn(false);
      setUsername('');
      setPassword('');
    }
  }, []);

  if (loggedIn) {
    return (
      <div>
        <h4>Profile</h4>
        <p>First Name: {userProfile.firstName}</p>
        <p>Middle Name: {userProfile.middleName}</p>
        <p>Last Name: {userProfile.lastName} </p> 
        <p>Section: {userProfile.section}</p>
        <button onClick={handleLogout}>Logout</button>
      </div>
    );
  }

  return (
    <div className="login-container">
      <h4>Login</h4>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        ref={usernameRef}
      />
      {error.username && <p className="error">{error.username}</p>} 

      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        ref={passwordRef}
      />
      {error.password && <p className="error">{error.password}</p>}

      <button onClick={togglePasswordVisibility}>Show Password</button>
      <button onClick={handleLogin} disabled={loading}>
        {loading ? 'Loading...' : 'Login'}
      </button>
    </div>
  );
};

const App = () => {
  const [userProfile, setUserProfile] = useState(null);

  return (
    <UserContext.Provider value={[userProfile, setUserProfile]}>
      <Login />
    </UserContext.Provider>
  );
};

export default App;

import React, { useReducer } from 'react';

const initialState = {
  input1: '',
  input2: '',
  operator: '',
  result: '',
};

const reducer = (state, action) => {
  switch (action.type) {
    case 'SET_INPUT1':
      return { ...state, input1: action.payload };
    case 'SET_INPUT2':
      return { ...state, input2: action.payload };
    case 'SET_OPERATOR':
      return { 
        ...state, 
        operator: action.payload,
        result: calculateResult(state.input1, state.input2, action.payload)
      };
  }
};

const calculateResult = (input1, input2, operator) => {
  const num1 = parseFloat(input1);
  const num2 = parseFloat(input2);

  if (isNaN(num1) || isNaN(num2)) return '';

  switch (operator) {
    case '+':
      return num1 + num2;
    case '-':
      return num1 - num2;
    case '*':
      return num1 * num2;
    case '÷':
      return num1 / num2;
    default:
      return '';
  }
};

const Operation = () => {
  const [state, dispatch] = useReducer(reducer, initialState);

  const handleInputChange = (inputNumber, value) => {
    if (inputNumber === 1) {
      dispatch({ type: 'SET_INPUT1', payload: value });
    } else {
      dispatch({ type: 'SET_INPUT2', payload: value });
    }
  };

  const handleOperator = (operator) => {
    if (state.input1 && state.input2) {
      dispatch({ type: 'SET_OPERATOR', payload: operator });
    }
  };

  return (
    <div className="operation-container">
      <h4>Mathematical Operations</h4>

      <div className="operation-display">
        <label>
          <input 
            type="number" 
            placeholder="Input 1"
            value={state.input1}
            onChange={(e) => handleInputChange(1, e.target.value)} 
          />
        </label>

        <span>{state.operator}</span>

        <label>
          <input 
            type="number" 
            placeholder="Input 2"
            value={state.input2}
            onChange={(e) => handleInputChange(2, e.target.value)} 
          />
        </label>

        {state.operator && (
          <>
            <span>=</span>
            <span>{state.result}</span>
          </>
        )}
      </div>

      <div className="operator-buttons">
        <button onClick={() => handleOperator('+')}>Addition</button>
        <button onClick={() => handleOperator('-')}>Subtraction</button>
        <button onClick={() => handleOperator('*')}>Multiplication</button>
        <button onClick={() => handleOperator('÷')}>Division</button>
      </div>
    </div>
  );
};

export default Operation;

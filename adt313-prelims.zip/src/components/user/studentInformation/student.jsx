import React from 'react';

const Student = () => {

  const studentData = {
    name: 'Eduardo S. Doldol',
    section: 'BSIT-3B',
  };

  return (
    <div className="student-container">
      <h4>Student Information</h4>
      <p>Name: {studentData.name}</p>
      <p>Section: {studentData.section}</p>
    </div>
  );
};

export default Student;
